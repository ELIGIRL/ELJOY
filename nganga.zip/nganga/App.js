import React, { Component } from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';

export default class App extends Component {
  render() {
    return (
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://hdclipartall.com/images/hi-clipart-hi-emotiocn-clipart-500.png' }}
            style={{ width: 200, height: 200 }}
          />
          <Text></Text>
        </View>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://th.bing.com/th/id/R.d9b41a7afea851339d7a61679be3f275?rik=jIFfzJdffx%2bh9A&riu=http%3a%2f%2fimages6.fanpop.com%2fimage%2fphotos%2f44500000%2fThe-Boyz-release-new-concept-photos-for-their-upcoming-7th-mini-album-BE-AWARE-the-boyz-44550761-1001-1251.png&ehk=jS2ikCGP5p65krd%2fvlJRY3vn3GPy%2bHy6RBwxhGDrb9c%3d&risl=&pid=ImgRaw&r=0' }}
            style={{ width: 200, height: 200 }}
          />
          <Text style={styles.text}>KIM SUNWOO !</Text>
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 10,
  },
});
