import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button, ScrollView } from 'react-native';

export default function App() {
  const [noteInput, setNoteInput] = useState('');
  const [notes, setNotes] = useState([]);

  const handleAddNote = () => {
    if (noteInput.trim()) {
      const newNote = { date: new Date(), note: noteInput };
      setNotes([...notes, newNote]);
      setNoteInput('');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Digital Note Taking App</Text>
      <TextInput
        style={styles.input}
        onChangeText={(text) => setNoteInput(text)}
        value={noteInput}
        placeholder="Enter note here"
        placeholderTextColor="#a0a0a0" 
        multiline={true}
      />
      <Button title="Add Note" onPress={handleAddNote} color="#808080" /> {}
      <ScrollView style={styles.notesContainer}>
        {notes.map((note, index) => (
          <View key={index} style={styles.noteContainer}>
            <Text style={styles.date}>{note.date.toLocaleString()}</Text>
            <Text style={styles.note}>{note.note}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'flex-start',
    backgroundColor: '#f5f5f5', 
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  input: {
    width: '100%',
    height: 100,
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#ccc', 
    backgroundColor: '#fff', 
    padding: 10,
    marginBottom: 20,
  },
  notesContainer: {
    width: '100%',
  },
  noteContainer: {
    width: '100%',
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#ccc',
    backgroundColor: '#fff', 
    marginBottom: 10,
    padding: 10,
  },
  date: {
    fontSize: 12,
    color: '#888', 
  },
  note: {
    fontSize: 16,
    color: '#333',
  },
});
