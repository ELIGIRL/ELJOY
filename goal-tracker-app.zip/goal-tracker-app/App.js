import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button, Image } from 'react-native';

export default function App() {
  const [weight, setWeight] = useState("");
  const [age, setAge] = useState("");
  const [goal, setGoal] = useState("");

  const calculateGoal = () => {
    const weightNum = parseFloat(weight);
    const ageNum = parseFloat(age);

    let calculatedGoal = "";
    if (!isNaN(weightNum) && !isNaN(ageNum)) {
      if (weightNum > 200 && ageNum > 53) {
        calculatedGoal = "Your daily calorie goal is X. It's recommended to do low-impact exercises like swimming and walking.";
      } else {
        calculatedGoal = "Your daily calorie goal is X";
      }
    } else {
      calculatedGoal = "Please enter valid weight and age.";
    }

    setGoal(calculatedGoal);
  }

  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://image.tmdb.org/t/p/original/jPCklfz8cAXfvRptmeNeYBa9Myf.jpg' }}
        style={{ width: 200, height: 200 }}
      />
      <Text style={{ fontSize: 40, color: 'red' }}>Goal Tracker</Text>

      <Text>Weight:</Text>
      <TextInput
        style={styles.input}
        onChangeText={(text) => setWeight(text)}
        value={weight}
        keyboardType="numeric"
      />
      <Text>Age:</Text>
      <TextInput
        style={styles.input}
        onChangeText={(text) => setAge(text)}
        value={age}
        keyboardType="numeric"
      />
      <Button
        title="Calculate Goal"
        onPress={calculateGoal}
      />
      <Text>{goal}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center', // Corrected spelling
    justifyContent: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    margin: 10,
    width: 200,
  },
});
